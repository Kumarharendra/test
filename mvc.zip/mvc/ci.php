<?php
include_once("Model.php");


$model = new Model();

		
		
if(isset($_POST['submit'])) {

	$name =$_POST['name'];
	
	$email = $_POST['email'];
	$con = $_POST['contact'];

}
		$result = $model->submit_index($name,$email,$con);
		
		
		?>