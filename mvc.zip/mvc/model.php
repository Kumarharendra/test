<?php
include_once 'DbConfig.php';
class Model extends DbConfig
{
	public function __construct()
	{
		parent::__construct();
	}
	
	public function submit_index($name,$email,$con)
	{
		$this->connection->("INSERT INTO users(name,age,email) VALUES('$name','$email','$con')");

	}
	
	}